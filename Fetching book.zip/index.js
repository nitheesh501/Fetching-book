import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import './index.css';


const BASE_URL = 'https://www.googleapis.com/books/v1/volumes';

const fetchBooks = async (searchTerm) => {
  try {
    const formattedTerm = searchTerm.replace(/ /g, '+');
    const response = await axios.get(`${BASE_URL}?q=${formattedTerm}`);
    return response.data.items;
  } catch (error) {
    console.error('Error fetching books:', error);
  }
};

const Book = ({ book }) => {
  const imageUrl = book.volumeInfo?.imageLinks?.thumbnail || '';
  const title = book.volumeInfo?.title;
  const authors = book.volumeInfo?.authors?.join(', ');

  return (
    <div className="book">
      {imageUrl && <img src={imageUrl} alt={title} />}
      <h3>{title}</h3>
      <p>by {authors}</p>
    </div>
  );
};

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [books, setBooks] = useState([]);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  useEffect(() => {
    const fetchData = async () => {
      const fetchedBooks = await fetchBooks(searchTerm);
      if (fetchedBooks) {
        setBooks(fetchedBooks);
      }
    };
    fetchData();
  }, [searchTerm]); // Update books on search term change

  return (
    <div className="App">
      <h1>Harry Potter Books</h1>
      <div className="search-container">
        <input
          type="text"
          placeholder="Search for Harry Potter books"
          value={searchTerm}
          onChange={handleSearchChange}
          className="search-input"
        />
      </div>
      {books.length > 0 && (
        <div className="book-list">
          {books.map((book) => (
            <Book key={book.id} book={book} />
          ))}
        </div>
      )}
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
